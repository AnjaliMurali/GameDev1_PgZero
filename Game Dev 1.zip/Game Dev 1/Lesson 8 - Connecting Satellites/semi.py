import pgzrun
from random import randint
from time import time

WIDTH = 800
HEIGHT = 400

satelites = []
lines = []
next_satelites = 0
start_time = time()
total_time = 0
end_time = 0
number_of_satelites = 8
gameover = False

def create_satelites():
    global start_time
    for count in range(0,number_of_satelites):
        satelite = Actor("satellite")
        satelite.pos = randint(40,WIDTH- 40),randint(40,HEIGHT- 40)
        satelites.append(satelite)

create_satelites()

def draw():
    global total_time
    screen.blit("background",(0,0))
    number=1
    for i in satelites:
        i.draw()
        screen.draw.text(str(number),(i.x,i.y+20))
        number += 1
    for line in lines:
        screen.draw.line(line[0],line[1],(255,0,0))
    if next_satelites < number_of_satelites:
        total_time = time() - start_time
        screen.draw.text(str(round(total_time,1)), (10,10) , fontsize=30)
        
    else:
        
        screen.draw.text(str(round(total_time,1)), (10,10) , fontsize=30)
    
    if gameover:
        if total_time<10:
            screen.fill("green")
        else:
            screen.fill("red")

def on_mouse_down(pos):
    global lines, next_satelites,satelites,gameover
    if satelites[next_satelites].collidepoint(pos):
        if next_satelites>0:
            lines.append((satelites[next_satelites-1].pos,satelites[next_satelites].pos))
            print(lines)
        next_satelites += 1
        if next_satelites==8:
            gameover=True

    else:
        lines=[]
        next_satelites=0

def update():
    pass

pgzrun.go()