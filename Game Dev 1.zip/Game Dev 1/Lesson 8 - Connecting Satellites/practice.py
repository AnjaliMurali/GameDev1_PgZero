import pgzrun
import random

WIDTH = 800
HEIGHT = 400

number_of_satellite = 10
sats = []
lines=[]
num = 0

for i in range(number_of_satellite):
    satellite = Actor("satellite")
    satellite.x = random.randint(50,WIDTH-50)
    satellite.y = random.randint(50,HEIGHT-50)
    sats.append(satellite)

def draw():
    screen.blit("background",(0,0))
    number=1
    for i in sats:
       i.draw()
       screen.draw.text(str(number),(i.x,i.y+20))
       number += 1

def on_mouse_down(pos):
    global num,lines
    if sats[num].collidepoint(pos):
        if num and num!=0:
            lines.append((sats[num-1].pos,sats[num].pos))
            print(lines)
        num +=1

    else:
        lines=[]
        num=0



pgzrun.go()