import pgzrun
import random
from time import time 

WIDTH = 800
HEIGHT = 400

number_of_satellite = 10
sats = []
lines=[]
next=0
start = time()
game_over = False

for i in range(number_of_satellite):
    satellite = Actor("satellite")
    satellite.x = random.randint(50,WIDTH-50)
    satellite.y = random.randint(50,HEIGHT-50)
    sats.append(satellite)



#print(start) 

def draw():
    global total
    screen.blit("background",(0,0))
    number=1
    for i in sats:
        #print(i)
        i.draw()
        screen.draw.text(str(number),(i.x,i.y+20))
        number += 1
    
    for line in lines:
        screen.draw.line(line[0],line[1],(255,0,0))

    #total = time() - start
    #print(start)
    #print(total)
    #screen.draw.text(str(round(total,1)), (10,10) , fontsize=30)
   
    if next < number_of_satellite:
        total = time() - start
        screen.draw.text(str(round(total,1)), (10,10) , fontsize=30)
    else:
        screen.draw.text(str(round(total,1)), (10,10) , fontsize=30)

    
    if game_over:
            screen.blit("gameover",(0,0))

def update():
    pass
    clock.schedule(time_up, 10.0)

def time_up():
    global game_over 
    game_over = True

def on_mouse_down(pos):
    global lines, next,sats

    if next < number_of_satellite:
        if sats[next].collidepoint(pos):
            if next>0:
                lines.append((sats[next-1].pos,sats[next].pos))
                print(lines)
            next += 1
        
            #To connect the last satellite to the first
            #if next == number_of_satellite:
                # Draw line from the last satellite to the first satellite to complete the loop
               # lines.append((sats[-1].pos, sats[0].pos))
                #print("Completed loop: ", lines)

        else:
            lines=[]
            next=0




pgzrun.go()