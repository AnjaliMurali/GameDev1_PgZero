import pgzrun
import random
from time import time

WIDTH = 800
HEIGHT = 400

number_of_planets = 8
planets = []
lines = []
next = 0
start = time()
gameover = False

# Planet names in order from the Sun
planet_names = [
    "mercury",
    "venus",
    "earth",
    "mars",
    "jupiter",
    "saturn",
    "uranus",
    "neptune"
]

# Create the planets
for name in planet_names:
    planet = Actor(name)

    # Put planets at random positions
    planet.x = random.randint(50, WIDTH - 50)
    planet.y = random.randint(70, HEIGHT - 50)

    planets.append(planet)


def draw():
    global total

    screen.blit("background", (0, 0))

    # Draw all planets
    for planet in planets:
        planet.draw()

    # Draw lines between planets that have been clicked
    for line in lines:
        screen.draw.line(line[0], line[1], (255, 0, 0))

    # Timer
    if next < number_of_planets:
        total = time() - start
        screen.draw.text(
            "Time: " + str(round(total, 1)),
            (10, 10),
            fontsize=30
        )

        screen.draw.text(
            "Click planets from the Sun!",
            (250, 10),
            fontsize=25
        )

    else:
        screen.draw.text(
            "Completed!",
            (300, 10),
            fontsize=35
        )

        screen.draw.text(
            "Time: " + str(round(total, 1)),
            (10, 50),
            fontsize=30
        )


def update():
    pass


def on_mouse_down(pos):
    global lines, next, planets, gameover

    # Don't allow more clicks after completing the challenge
    if next >= number_of_planets:
        return

    # Check whether the correct planet was clicked
    if planets[next].collidepoint(pos):

        # Add a line from the previous planet
        if next > 0:
            lines.append(
                (planets[next - 1].pos, planets[next].pos)
            )

        next += 1

        # Check if all planets have been clicked
        if next == number_of_planets:
            gameover = True

    else:
        # Wrong planet - reset the challenge
        lines = []
        next = 0
        print("Wrong planet! Start again.")


pgzrun.go()