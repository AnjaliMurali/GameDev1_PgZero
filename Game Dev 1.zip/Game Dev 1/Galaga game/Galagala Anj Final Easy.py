import pgzrun
WIDTH=800
HEIGHT=500
bulletList=[]
posList=[]
ship=Actor("galaga")
ship.pos=(400,420)
bugList=[]
y=40
x=40
direction = 1 
bullets_to_remove=[]
bugs_to_remove=[]
timeUp = False 
gameover = False
win = False
for i in range(3):
    for j in range(6):
        bug=Actor("bug")
        bug.pos=(x,y)
        bugList.append(bug)
        x+=60
    y+=50
    x=40
def draw():
    screen.fill("black")
    ship.draw()
    for i in bugList:
        i.draw()
    for i in bulletList:
        i.draw()
    if timeUp:
        timeup()
    if gameover:
        gameOver()
    if win:
        YouWin()
def update():
    global down,direction,win
       
    if ship.x<560:
        if keyboard.d:
            ship.x+=2
    if ship.x>40:
        if keyboard.a:
            ship.x-=2
    
    for i in bulletList:
        i.y-=2
        if i.y<0:
            bulletList.remove(i)
        for bug in bugList:
                if bug.colliderect(i):  
                    # score+=100
                    #bulletList.remove(i)
                    #bugList.remove(b ug) 
                    bullets_to_remove.append(i)
                    bugs_to_remove.append(bug)   
      
    if bugList:
        for i in bugList:
            i.x += 2 * direction
            if i.colliderect(ship):
                gameOver()

        # Check right edge
        if bugList[-1].x > 710:
            direction = -1
            for i in bugList:
                i.y += 30

        # Check left edge
        if bugList[0].x < 40:
            direction = 1
            for i in bugList:
                i.y += 30
    
    else: 
        win = True

    for bug in bugs_to_remove:
            if bug in bugList:
                bugList.remove(bug)

    for bullet in bullets_to_remove:
        if bullet in bulletList:
            bulletList.remove(bullet)


    

def on_key_down(key):
    if key==keys.SPACE:
        bullet=Actor("bullet")
        bullet.pos=(ship.x-1,ship.y-35)
        if len(bulletList)<10:
            bulletList.append(bullet)
        else:
            bulletList.pop(0)
            bulletList.append(bullet)

def timeup(): 
    global timeUp 
    timeUp=True
    screen.fill("light blue")
    screen.draw.text("Time's Up", (250,300),fontsize=60, color="red")
    clock.unschedule(timeup)

def gameOver(): 
    global gameover 
    gameover=True
    screen.fill("light blue")
    screen.draw.text("Game Over", (250,300),fontsize=60, color="red")
    clock.unschedule(timeup)

def YouWin(): 
    global win
    win=True
    screen.fill("light blue")
    screen.draw.text("You Win", (250,300),fontsize=60, color="red")
    clock.unschedule(timeup)

clock.schedule(timeup,60.0)
pgzrun.go()