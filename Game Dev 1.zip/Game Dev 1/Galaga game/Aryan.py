import pgzrun

WIDTH=800
HEIGHT=600

galaga=Actor("galaga")
galaga.pos=(400,550)
bugs=[]
for j in range(5):
    for i in range(3 + j):
        bug=Actor("bug")
        bugs.append(bug)
        bugs[-1].x=20+40*i
        bugs[-1].y=30*j
   
d=1
md=False
bullets=[]
bullets_to_remove=[]
bugs_to_remove=[]


score=0
win=False
gameover=False

def draw():
    screen.fill("#ba03fc")
    galaga.draw()
    for bug in bugs:
        bug.draw()
    for bullet in bullets:
        bullet.draw()
    screen.draw.text("Score" + str(score),(500,200))
    if win:
        screen.draw.text("You Win", (250,300))
    if gameover:
        screen.draw.text("GameOver ", (250,300))  

def update():
    global d, md , score, win 
    md=False
    if keyboard.left:
        galaga.x-=10
        if galaga.x<=50:
            galaga.x=50

    if keyboard.right:
        galaga.x+=10
        if galaga.x>=750:
            galaga.x=750

    if len(bugs)>0 and (bugs[0].x<20 or bugs[-1].x>780):
        d=d*-1
        md=True

    bullets_to_remove.clear()  # Ensure the list is empty
    bugs_to_remove.clear()  # Ensure the list is empty

    for bug in bugs:
        bug.x+=d*5  
        if md==True:
            if bug.y<=HEIGHT:
                bug.y+=50   

        for bullet in bullets:
            if bug.colliderect(bullet):
                score+=100
                #bullets.remove(bullet)
                #bugs.remove(bug)
                bullets_to_remove.append(bullet)
                bugs_to_remove.append(bug)
    
    

    for bug in bugs_to_remove:
        if bug in bugs:
            bugs.remove(bug)

    for bullet in bullets_to_remove:
        if bullet in bullets:
            bullets.remove(bullet)

    if len(bugs)==0:
        win = True

    for bullet in bullets:
        bullet.y-=5
    
         

def on_key_down(key):
    if key == keys.SPACE:
        bullet=Actor("bullet")
        bullets.append(bullet)
        bullet.x=galaga.x
        bullet.y=galaga.y-37 
    
def time_up():
    global gameover
    gameover = True

#clock.schedule(time_up, 3.0)
pgzrun.go()