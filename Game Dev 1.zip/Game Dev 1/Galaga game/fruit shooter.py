import pgzrun
import random

WIDTH = 800
HEIGHT = 500

bulletList = []
fruitList = []
bombList = []

bullets_to_remove = []
fruits_to_remove = []

ship = Actor("ship")
ship.pos = (400, 440)

score = 0
timeUp = False
gameover = False
win = False

# -------------------------
# CREATE FRUITS
# -------------------------

fruit_images = ["apple", "banana", "orange"]

for i in range(12):
    fruit = Actor(random.choice(fruit_images))
    fruit.pos = (
        random.randint(50, 750),
        random.randint(50, 300)
    )
    fruitList.append(fruit)

# -------------------------
# CREATE BOMBS
# -------------------------

for i in range(5):
    bomb = Actor("bomb")
    bomb.pos = (
        random.randint(50, 750),
        random.randint(50, 300)
    )
    bombList.append(bomb)


# -------------------------
# DRAW
# -------------------------

def draw():
    screen.fill("light blue")

    if not gameover and not timeUp and not win:
        ship.draw()

        for fruit in fruitList:
            fruit.draw()

        for bomb in bombList:
            bomb.draw()

        for bullet in bulletList:
            bullet.draw()

        screen.draw.text(
            "Score: " + str(score),
            (20, 20),
            fontsize=35,
            color="black"
        )

    if timeUp:
        timeup()

    if gameover:
        gameOver()

    if win:
        YouWin()


# -------------------------
# UPDATE
# -------------------------

def update():
    global score, gameover, win

    if gameover or timeUp or win:
        return

    # Move ship left and right
    if keyboard.d:
        if ship.x < 760:
            ship.x += 5

    if keyboard.a:
        if ship.x > 40:
            ship.x -= 5

    # -------------------------
    # MOVE BULLETS
    # -------------------------

    bullets_to_remove.clear()
    fruits_to_remove.clear()

    for bullet in bulletList:

        bullet.y -= 6

        if bullet.y < 0:
            bullets_to_remove.append(bullet)

        # Check bullet against fruits
        for fruit in fruitList:
            if bullet.colliderect(fruit):
                fruits_to_remove.append(fruit)
                bullets_to_remove.append(bullet)
                score += 10
                break

        # Check bullet against bombs
        for bomb in bombList:
            if bullet.colliderect(bomb):
                bullets_to_remove.append(bullet)
                break

    # -------------------------
    # REMOVE BULLETS
    # -------------------------

    for bullet in bullets_to_remove:
        if bullet in bulletList:
            bulletList.remove(bullet)

    # -------------------------
    # REMOVE FRUITS
    # -------------------------

    for fruit in fruits_to_remove:
        if fruit in fruitList:
            fruitList.remove(fruit)

    # -------------------------
    # MOVE BOMBS
    # -------------------------

    for bomb in bombList:
        bomb.y += 1

        # Wrap bomb around screen
        if bomb.y > HEIGHT:
            bomb.y = 0
            bomb.x = random.randint(50, 750)

        # Bomb hits player
        if bomb.colliderect(ship):
            gameOver()

    # -------------------------
    # CHECK WIN
    # -------------------------

    if len(fruitList) == 0:
        win = True


# -------------------------
# SHOOT
# -------------------------

def on_key_down(key):

    if key == keys.SPACE:

        if not gameover and not timeUp and not win:

            bullet = Actor("bullet")
            bullet.pos = (ship.x, ship.y - 30)

            if len(bulletList) < 10:
                bulletList.append(bullet)

            else:
                bulletList.pop(0)
                bulletList.append(bullet)


# -------------------------
# TIME UP
# -------------------------

def timeup():
    global timeUp

    timeUp = True

    screen.fill("light blue")

    screen.draw.text(
        "Time's Up!",
        (250, 200),
        fontsize=70,
        color="red"
    )

    screen.draw.text(
        "Score: " + str(score),
        (320, 300),
        fontsize=40,
        color="black"
    )

    clock.unschedule(timeup)


# -------------------------
# GAME OVER
# -------------------------

def gameOver():
    global gameover

    gameover = True

    screen.fill("light blue")

    screen.draw.text(
        "Game Over!",
        (250, 200),
        fontsize=70,
        color="red"
    )

    screen.draw.text(
        "You hit a bomb!",
        (275, 290),
        fontsize=35,
        color="black"
    )

    screen.draw.text(
        "Score: " + str(score),
        (320, 350),
        fontsize=40,
        color="black"
    )

    clock.unschedule(timeup)


# -------------------------
# YOU WIN
# -------------------------

def YouWin():
    global win

    win = True

    screen.fill("light green")

    screen.draw.text(
        "You Win!",
        (270, 200),
        fontsize=70,
        color="green"
    )

    screen.draw.text(
        "All fruits collected!",
        (250, 290),
        fontsize=35,
        color="black"
    )

    screen.draw.text(
        "Score: " + str(score),
        (320, 350),
        fontsize=40,
        color="black"
    )

    clock.unschedule(timeup)


# -------------------------
# START 60 SECOND TIMER
# -------------------------

clock.schedule(timeup, 60.0)

pgzrun.go()