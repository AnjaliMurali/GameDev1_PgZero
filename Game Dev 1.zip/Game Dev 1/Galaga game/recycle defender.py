import pgzrun
import random

WIDTH = 800
HEIGHT = 500

# --------------------------------
# BIN
# --------------------------------

bin = Actor("bin")
bin.midbottom = (400, 480)


# --------------------------------
# GAME VARIABLES
# --------------------------------

score = 0
timeUp = False
gameover = False
win = False


# --------------------------------
# ITEM LISTS
# --------------------------------

non_recyclableList = []
recyclableList = []


# --------------------------------
# CREATE NON-RECYCLABLE ITEMS
# --------------------------------

non_recyclable_images = [
    "plastic"
]

for i in range(8):

    item = Actor(random.choice(non_recyclable_images))

    # Start near the TOP of the screen
    item.x = random.randint(50, 750)
    item.y = random.randint(50, 150)

    non_recyclableList.append(item)


# --------------------------------
# CREATE RECYCLABLE ITEMS
# --------------------------------

recyclable_images = [
    "item1",
    "item2",
    "item3"
]

for i in range(6):

    item = Actor(random.choice(recyclable_images))

    # Start VERY FAR from the bin
    item.x = random.randint(50, 750)
    item.y = random.randint(50, 150)

    recyclableList.append(item)


# --------------------------------
# DRAW
# --------------------------------

def draw():

    # --------------------------------
    # NORMAL GAME
    # --------------------------------

    if not gameover and not timeUp and not win:

        screen.fill("light green")

        bin.draw()

        for item in non_recyclableList:
            item.draw()

        for item in recyclableList:
            item.draw()

        screen.draw.text(
            "Score: " + str(score),
            (20, 20),
            fontsize=35,
            color="black"
        )

    # --------------------------------
    # GAME OVER
    # --------------------------------

    elif gameover:

        screen.fill("light blue")

        screen.draw.text(
            "Game Over!",
            center=(400, 180),
            fontsize=70,
            color="red"
        )

        screen.draw.text(
            "You touched a recyclable!",
            center=(400, 280),
            fontsize=30,
            color="black"
        )

        screen.draw.text(
            "Score: " + str(score),
            center=(400, 340),
            fontsize=40,
            color="black"
        )

    # --------------------------------
    # TIME UP
    # --------------------------------

    elif timeUp:

        screen.fill("light blue")

        screen.draw.text(
            "Time's Up!",
            center=(400, 180),
            fontsize=70,
            color="red"
        )

        screen.draw.text(
            "Score: " + str(score),
            center=(400, 280),
            fontsize=40,
            color="black"
        )

    # --------------------------------
    # WIN
    # --------------------------------

    elif win:

        screen.fill("light green")

        screen.draw.text(
            "You Win!",
            center=(400, 180),
            fontsize=70,
            color="green"
        )

        screen.draw.text(
            "Great recycling!",
            center=(400, 280),
            fontsize=35,
            color="black"
        )

        screen.draw.text(
            "Score: " + str(score),
            center=(400, 340),
            fontsize=40,
            color="black"
        )


# --------------------------------
# UPDATE
# --------------------------------

def update():

    global score
    global gameover
    global win

    # Don't update after game ends
    if gameover or timeUp or win:
        return


    # --------------------------------
    # MOVE BIN
    # --------------------------------

    if keyboard.d:

        if bin.x < 760:
            bin.x += 5

    if keyboard.a:

        if bin.x > 40:
            bin.x -= 5


    # --------------------------------
    # MOVE NON-RECYCLABLE ITEMS
    # --------------------------------

    for item in non_recyclableList:

        item.y += 2

        # Reached bottom
        if item.y > HEIGHT:

            item.y = random.randint(30, 100)
            item.x = random.randint(40, 760)

        # COLLECT NON-RECYCLABLE
        if bin.colliderect(item):

            score += 10

            # Move collected item back to top
            item.y = random.randint(30, 100)
            item.x = random.randint(40, 760)


    # --------------------------------
    # MOVE RECYCLABLE ITEMS
    # --------------------------------

    for item in recyclableList:

        item.y += 2

        # Reached bottom
        if item.y > HEIGHT:

            item.y = random.randint(30, 100)
            item.x = random.randint(40, 760)

        # TOUCHING RECYCLABLE = GAME OVER
        if bin.colliderect(item):
            print("COLLISION WITH RECYCLABLE:", item.pos)

            gameover = True
            return


    # --------------------------------
    # WIN CONDITION
    # --------------------------------

    if score >= 100:

        win = True


# --------------------------------
# TIME LIMIT
# --------------------------------

def timeup():

    global timeUp

    # Only trigger if game is still running
    if not gameover and not win:

        timeUp = True


# --------------------------------
# START 60 SECOND TIMER
# --------------------------------

clock.schedule(timeup, 60.0)


# --------------------------------
# START GAME
# --------------------------------

pgzrun.go()