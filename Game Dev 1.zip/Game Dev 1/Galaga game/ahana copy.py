import pgzrun

WIDTH = 1000
HEIGHT = 600

movedown=False
gameover = False
dir=1

galaga=Actor("galaga")
galaga.x=500
galaga.y=540

bullet=Actor("bullet")

bugs=[]
for i in range(5):
    bug=Actor("bug")
    bug.x=(i*70)+40
    bugs.append(bug)

def draw():
    screen.fill("blue")
    galaga.draw()
    for i in bugs:
        i.draw()
    if gameover:
        gameOver()


def update():
    global movedown,dir
    movedown = False
    if keyboard.left:
        galaga.x+=-10
        if galaga.x<0:
            galaga.x=0
    if keyboard.right:
        galaga.x+=10
        if galaga.x>1000:
            galaga.x=1000
    
    for bug in bugs:         
        if (bug.x<20 or bug.x>1000):
            dir=dir*-1
            movedown=True
    
    for bug in bugs:
        bug.x+=dir*4
        if movedown == True:
            bug.y+=40
        if bug.colliderect(galaga):
            gameOver()
            
def gameOver(): 
    global gameover 
    gameover=True
    screen.fill("light blue")
    screen.draw.text("GAME OVER", (250,300),fontsize=60, color="red")
pgzrun.go()