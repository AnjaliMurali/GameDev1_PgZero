import pgzrun
WIDTH = 400
HEIGHT = 400
dir = 1
bugspeed = 45
i3 = 0
s = Actor("galaga")
s.y = 362.325936287732299774936
s.x = 200
i1 = 20
i2 = 20
i4 = 0
list2 = []
list = []
for i in range(20):
    
    b = Actor("bug")
    b.x = i1
    b.y = i2
    
    list.append(b)
    i1 = i1 + 40
    if i1 >= 220:
        i1 = 20
        i2 += 40

def draw():
    screen.fill("black")
    s.draw()
    for i in list:
        i.draw()
    for i in list2:
        i.draw()
    




def update():
    global dir
    global i3
    global bugspeed
    global i4
    i3 += 1
    for i in list:
        for j in list2:
            if j.colliderect(i):
                list.remove(i)
                list2.remove(j)
    if i3 >= bugspeed:
        i3 = 0
        for i in list:
            i.x += 40 * dir
    for i in list:
        if i.x >= 400 or i.x <= 0:
            dir = dir * -1
            for i in list:
                i.y += 40
                i.x += 40 * dir
    if i4 <= 0:
        if keyboard.space:
            shoot()
            i4 = 1
    if not keyboard.space:
        i4 = 0
    if keyboard.a or keyboard.left and s.x > 36:
        s.x -= 10
    if not s.x > 36:
        s.x = 36
    if keyboard.d or keyboard.right and s.x < 364:
        s.x += 10
    if s.x > 364:
        s.x = 364
    for i in list2:
        i.y -= 10
        if i.y <= -10:
            list2.remove(i)
def shoot():
    global list2
    l = Actor("bullet")
    l.x = s.x
    l.y = 340
    list2.append(l)





pgzrun.go()