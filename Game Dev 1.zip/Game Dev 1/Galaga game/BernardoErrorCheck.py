import pgzrun
WIDTH=470

HEIGHT=470
bull=[]
bugs=[]
ship=Actor("galaga")
ship.pos=235,400
score=0
gameover=False
timeup = False

for i in range(5):
    for j in range(3):
        bug=Actor("bug")
        bug.x = 100+70*i
        bug.y = 80 + 30*j
        bugs.append(bug)
def on_key_down(key):
    if key == keys.SPACE:
        bullet=Actor("bullet")
        bullet.x = ship.x
        bullet.y = ship.y-30
        bull.append(bullet)


def update():
    global score
    if(keyboard.left):
        ship.x-=10
        if(ship.x<0):
            ship.x=0
    if(keyboard.right):
        ship.x+=10
        if(ship.x>470):
            ship.x=420

    for b in bull:
        b.y-=5
        for bug in bugs:
                if bug.colliderect(b):
                    score+=100
                    bull.remove(b)
                    bugs.remove(bug) 
    
    for bug in bugs:
        bug.y+=1
        if bug.colliderect(ship):
            gameOver()

def draw():
    screen.fill("blue")
    ship.draw()
    for i in bull:
        i.draw()
    for b in bugs:
        b.draw()
    screen.draw.text(str(score),(0,0))
    if gameover:
        screen.fill("red")
        screen.draw.text("Game Over", (235,235))
    if timeup:
        screen.fill("yellow")
        screen.draw.text("Time Up", (235,235))


def gameOver():
    global gameover
    gameover = True

def Time_UP(): 
    global timeup
    timeup=True

clock.schedule(Time_UP,10)

pgzrun.go()