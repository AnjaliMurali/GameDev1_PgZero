import pgzrun
import random

WIDTH = 1200
HEIGHT = 600

BLUE = (0,0,255)
speed=5

ship = Actor('galaga')
ship.pos = (WIDTH//2, HEIGHT-60)

direction = 1

enemies = []
#part3
#We want 8 enemies
for i in range(8):
    for j in range(4):
        bug = Actor('bug')
        enemies.append(bug)
        enemies[-1].x = 100+ 70*i
        enemies[-1].y = 0+50*j

bullets=[]
score = 0

#part3
ship.dead = False
#ship.countdown = 90

def draw():
    screen.clear()
    screen.fill("blue")
     
    for bullet in bullets:
        bullet.draw()
    for enemy in enemies:
        enemy.draw()
   
    #Part3
    if ship.dead == False:
        ship.draw()
    displayScore()
    if len(enemies) == 0 and ship.dead == False:
        youWin()
    elif len(enemies) == 0 and ship.dead == True:
        gameOver()


#part3
def gameOver():
    screen.draw.text("GAME OVER", (250,300))

def youWin():
    screen.draw.text("You Win", (250,300))

def on_key_down(key):
    #part3
    if ship.dead == False:
        if key == keys.SPACE: 
            bullets.append(Actor('bullet'))
            bullets[-1].x = ship.x
            bullets[-1].y = ship.y-50

def update():
    global score,direction
    moveDown = False
    for bullet in bullets:
        if bullet.y <=0 :
            bullets.remove(bullet)
        else:
            bullet.y -= 10

    #Part3
    if ship.dead == False:
        if keyboard.left:
            ship.x -= speed
            if ship.x <= 0:
                ship.x = 0
        elif keyboard.right:
            ship.x += speed
            if ship.x >= WIDTH:
                ship.x = WIDTH

    #Part3
    if len(enemies) == 0:
        gameOver()

    if len(enemies)>0  and (enemies[-1].x > WIDTH-80 or enemies[0].x < 80):
        moveDown = True
        direction = direction*-1
    for enemy in enemies:
            enemy.x += 5*direction
            if moveDown == True:
                enemy.y += 50
                if enemy.y >= HEIGHT:
                    #part3
                    enemies.remove(enemy)
                    #enemy.y  = -100
                    #enemy.x = random.randint(50,WIDTH-50)
               
            for bullet in bullets :
                if enemy.colliderect(bullet):
                    score +=100
                    #we also want to destory the bullet
                    bullets.remove(bullet)
                    #destroy the bug
                    enemies.remove(enemy)
                    #Part3
                    if len(enemies) == 0 and ship.dead == False:
                        youWin()
                #Part3
                #checking for enemy hits the ship
            if enemy.colliderect(ship):
                ship.dead = True
            


def displayScore():
    screen.draw.text(str(score), (50,30))

pgzrun.go()