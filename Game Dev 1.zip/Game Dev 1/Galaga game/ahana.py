import pgzrun

WIDTH = 1000
HEIGHT = 600


movedown = False
dir = 1  # 1 means right, -1 means left

galaga=Actor("galaga")
galaga.x=500
galaga.y=540

bullet=Actor("bullet")

bugs=[]
Bullets=[]
for i in range(5):
    bug=Actor("bug")
    bug.x=(i*70)+40
    bugs.append(bug)

def draw():
    screen.fill("blue")
    galaga.draw()
    for i in bugs:
        i.draw()
    for bullet in Bullets:
        bullet.draw()

def on_key_down(key):
    if key == keys.SPACE:
        Bullet=Actor("bullet")
        Bullets.append(Bullet)
        Bullet.x=galaga.x
        Bullet.y=galaga.y-37

def update():
    global movedown,dir
    movedown = False
    if keyboard.left:
        galaga.x+=-10
        if galaga.x<0:
            galaga.x=0
    if keyboard.right:
        galaga.x+=10
        if galaga.x>1000:
            galaga.x=1000

    if (bugs[0].x<20 or bugs[-1].x>1000):
        dir=dir*-1
        movedown=True
  
    
    for bug in bugs:
        bug.x+=dir*4
        if movedown == True:
            bug.y+=40
            
    for bullet in Bullets:
            bullet.y-=5
            for bug in bugs:
                if bug.colliderect(bullet):
                    # score+=100
                    Bullets.remove(bullet)
                    bugs.remove(bug) 
       
        

pgzrun.go()