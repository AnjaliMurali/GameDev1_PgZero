import pgzrun
import time

HEIGHT= 700
WIDTH = 1200

bugs=[]
Bullets=[]
score = 0
dir = 1
movedown=False
gameover=False

bullets_to_remove=[]
bugs_to_remove=[]

Galaga=Actor("galaga")
Galaga.y=(655)
Galaga.x=(585)


for j in range(5):
    for i in range(5):
        Bug=Actor("bug")
        Bug.x=(585+55*i)
        Bug.y=(30 + 50*j)
        bugs.append(Bug)


def draw():
    screen.fill("light blue")
    Galaga.draw()
    for b in bugs:
        b.draw()
    for bullet in Bullets:
        bullet.draw()
    screen.draw.text("Score : " + str(score),(50,100), color="red")
    if len(bugs) == 0:
        gameOver()
    if gameover:
        gameOver()
        
def on_key_down(key):
    if key == keys.SPACE:
        Bullet=Actor("bullet")
        Bullets.append(Bullet)
        Bullet.x=Galaga.x
        Bullet.y=Galaga.y-37


def update():
    global score,dir,movedown
    movedown = False
    if gameover ==False: 
        if keyboard.left:
            Galaga.x=Galaga.x-15
            if Galaga.x<20:
                Galaga.x=20
        if keyboard.right:
            Galaga.x=Galaga.x+15
            if Galaga.x>1180:
                Galaga.x=1180
        
        for bullet in Bullets:
            bullet.y-=5
            for bug in bugs:
                if bug.colliderect(bullet):
                    score+=100
                    #Bullets.remove(bullet)
                    #bugs.remove(bug) 
                    bullets_to_remove.append(bullet)
                    bugs_to_remove.append(bug)
        

        for bug in bugs_to_remove:
            if bug in bugs:
                bugs.remove(bug)

        for bullet in bullets_to_remove:
            if bullet in Bullets:
                Bullets.remove(bullet)

        if len(bugs)>0  and (bugs[0].x<20 or bugs[-1].x>1180):
            dir=dir*-1
            movedown=True
        
        for bug in bugs:
            bug.x+=dir*5  
            if movedown==True:
                if bug.y<=HEIGHT:
                    bug.y+=50
            if bug.colliderect(Galaga):
                gameOver()

        
        if len(bugs) == 0:
            gameOver()
    
def gameOver(): 
    global gameover 
    gameover=True
    screen.fill("light blue")
    screen.draw.text("GAME OVER", (250,300),fontsize=60, color="red")


pgzrun.go()