import pgzrun
import random

WIDTH = 800
HEIGHT = 475

BLUE = (0,0,255)
speed=5

ship = Actor('galaga')
ship.pos = (WIDTH//2, HEIGHT-60)

direction = 1

enemies = []
for i in range(5):
    bug = Actor('bug')
    enemies.append(bug)
    enemies[-1].x = 100+ 90*i
    enemies[-1].y = -100

bullets=[]
score = 0

def draw():
    screen.fill((0, 0, 255))
    ship.draw()
    for bullet in bullets:
        bullet.draw()
    for enemy in enemies:
        enemy.draw()
    screen.draw.text(str(score), (50,30))

def on_key_down(key):
    if key == keys.SPACE: 
        bullets.append(Actor('bullet'))
        bullets[-1].x = ship.x
        bullets[-1].y = ship.y-50

def update():
    global score,direction
    moveDown = False
    for bullet in bullets:
        if bullet.y <=0 :
            bullets.remove(bullet)
        else:
            bullet.y -= 10

    if keyboard.left:
        ship.x -= speed
        if ship.x <= 0:
            ship.x = 0
    elif keyboard.right:
        ship.x += speed
        if ship.x >= WIDTH:
            ship.x = WIDTH

    if len(enemies)>0  and (enemies[-1].x > WIDTH-80 or enemies[0].x < 80):
        moveDown = True
        direction = direction*-1
    for enemy in enemies:
            enemy.x += 1*direction
            if moveDown == True:
                enemy.y += 50
                if enemy.y >= HEIGHT:
                    enemy.y  = -100
                    enemy.x = random.randint(50,WIDTH-50)
    for bullet in bullets :
        if enemy.colliderect(bullet):
            score +=100 
            #we also want to destory the bullet
            bullets.remove(bullet)
            #destroy the bug
            enemies.remove(enemy)


pgzrun.go()