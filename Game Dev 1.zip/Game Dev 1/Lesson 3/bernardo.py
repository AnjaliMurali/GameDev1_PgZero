import pgzrun

WIDTH = 500
HEIGHT= 400

def draw():
    screen.fill("yellow")
    r = Rect((100,100),(150,100))
    screen.draw.rect(r,"red")

pgzrun.go()