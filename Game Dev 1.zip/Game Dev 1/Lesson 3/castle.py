"""
Build a Castle 🏰
Draw a castle using rectangles. Add towers, windows, doors and a wall.
"""


import pgzrun

WIDTH = 1000
HEIGHT = 1000

def draw():
    #screen.fill("pink")
    # Main castle wall
    screen.draw.filled_rect(Rect(200, 250, 300, 200), "gray")

    # Left tower
    screen.draw.filled_rect(Rect(150, 180, 100, 270), "gray")

    # Right tower
    screen.draw.filled_rect(Rect(450, 180, 100, 270), "gray")

    # Left tower windows
    screen.draw.filled_rect(Rect(180, 220, 30, 40), "blue")
    screen.draw.filled_rect(Rect(180, 300, 30, 40), "blue")

    # Right tower windows
    screen.draw.filled_rect(Rect(490, 220, 30, 40), "blue")
    screen.draw.filled_rect(Rect(490, 300, 30, 40), "blue")

    # Main wall windows
    screen.draw.filled_rect(Rect(260, 290, 40, 50), "blue")
    screen.draw.filled_rect(Rect(400, 290, 40, 50), "blue")

    # Castle door
    screen.draw.filled_rect(Rect(325, 350, 50, 100), "brown")

pgzrun.go()
