capitals={"Netherlands":"Amsterdam","South Africa":"Pretoria"}
print(capitals)

capitals["UK"] = "London"
print(capitals)

print(capitals["Netherlands"])

x = input("Enter the country you are looking for?")
if x in capitals:
    print("Yes")
else:
    print("No")
