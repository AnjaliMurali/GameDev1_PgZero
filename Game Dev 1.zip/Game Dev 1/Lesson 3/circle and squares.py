import pgzrun
WIDTH = 800
HEIGHT = 600

def draw():
    screen.clear()
    screen.fill("white")

    y = HEIGHT // 2

    for x in range(40, WIDTH, 80):
        # Draw a circle
        screen.draw.filled_circle((x, y), 20, "red")

        # Draw a square next to it
        screen.draw.filled_rect(
            Rect((x + 40, y - 20), (40, 40)),
            "blue"
        )

pgzrun.go()