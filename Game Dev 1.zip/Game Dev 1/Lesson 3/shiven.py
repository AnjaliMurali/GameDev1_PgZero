import pgzrun

WIDTH = 300
HEIGHT = 300

def draw():
    screen.fill("red")
    r = Rect((100,100),(150,75))
    screen.draw.rect(r,"yellow")

pgzrun.go()