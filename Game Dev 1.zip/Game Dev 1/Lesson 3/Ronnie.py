import pgzrun
WIDTH = 300
HEIGHT = 300

def draw():
    screen.fill("red")
    r1 = Rect((WIDTH/2,HEIGHT/2),(200,100))
    r1.center= WIDTH/2,HEIGHT/2
    screen.draw.rect(r1,"white")

pgzrun.go()