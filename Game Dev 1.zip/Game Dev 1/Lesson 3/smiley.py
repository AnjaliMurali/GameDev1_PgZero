import pgzrun

WIDTH = 600
HEIGHT = 600

def draw():
    screen.clear()

    # Face
    screen.draw.filled_circle((300, 300), 150, "yellow")
    screen.draw.circle((300, 300), 150, "black")

    # Eyes
    screen.draw.filled_circle((250, 260), 15, "black")
    screen.draw.filled_circle((350, 260), 15, "black")

    # Mouth (rectangle smile)
    mouth = Rect((230, 350), (140, 25))
    screen.draw.filled_rect(mouth, "black")

pgzrun.go()