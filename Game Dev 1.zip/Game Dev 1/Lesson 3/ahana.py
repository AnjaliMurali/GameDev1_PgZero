import pgzrun

WIDTH = 300
HEIGHT = 300

def draw():
    screen.fill("pink")

pgzrun.go()