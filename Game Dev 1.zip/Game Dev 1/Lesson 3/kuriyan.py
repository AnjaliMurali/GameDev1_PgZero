import pgzrun

WIDTH=300
HEIGHT=300

def draw():
    screen.fill("blue")
    r = Rect((150,150),(150,100))
    r.center= 150,150
    screen.draw.rect(r,"red")

pgzrun.go()