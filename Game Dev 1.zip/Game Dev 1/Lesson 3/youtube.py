import pgzrun

WIDTH = 500
HEIGHT = 400

def draw():
    screen.fill("White")

    r1 = Rect((100, 100), (200, 150))
    r1.center = 250, 250
    screen.draw.filled_rect(r1, "red")

    # Draw triangle outline
    screen.draw.line((200, 200), (200, 300), "white")
    screen.draw.line((200, 200), (300, 250), "white")
    screen.draw.line((200, 300), (300, 250), "white")

    # Fill triangle with white lines
    for y in range(200, 301):

        if y <= 250:
            x2 = 200 + (y - 200) * 2
        else:
            x2 = 300 - (y - 250) * 2

        screen.draw.line((200, y), (x2, y), "white")

  

    
    
   
    # x = 200
    # y = 200
    # h = 100
    # for i in range(20):
    #     r2 = Rect((x,y),(5,h))
    #     r2.center = 
    #     screen.draw.filled_rect(r2,"white")
    #     x +=5
    #     h -= 10
    #     y -= 5

pgzrun.go()