import pgzrun

WIDTH = 450
HEIGHT =450

def draw():
    screen.fill("yellow")
    r = Rect((225,225),(100,50))
    r.center = 225,225
    screen.draw.rect(r,"blue")

pgzrun.go()