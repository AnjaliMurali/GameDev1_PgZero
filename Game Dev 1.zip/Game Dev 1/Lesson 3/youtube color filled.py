import pgzrun
import pygame  # Import Pygame directly

WIDTH = 500
HEIGHT = 400

def draw():
    screen.fill("White")
    
    # Draw the red rectangle
    r1 = Rect((100, 100), (200, 150))
    r1.center = 250, 250
    screen.draw.filled_rect(r1, "red")
   
    # Define the vertices of the triangle
    triangle_points = [(200, 200), (200, 300), (300, 250)]
   
    # Draw and fill the triangle using pygame directly
    pygame.draw.polygon(screen.surface, "white", triangle_points)

pgzrun.go()
