import pgzrun

WIDTH = 400
HEIGHT=400

def draw():
    screen.fill("blue")
    r = Rect((200,200),(50,50))
    r.center = 200,200
    screen.draw.rect(r,"yellow")

pgzrun.go()