import pgzrun

WIDTH = 400
HEIGHT = 400

def draw():
    screen.fill("green")
    r = Rect((200,200),(100,150))
    screen.draw.rect(r,"yellow")

pgzrun.go()