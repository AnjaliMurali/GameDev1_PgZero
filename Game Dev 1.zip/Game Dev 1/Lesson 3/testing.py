import pgzrun
import random

WIDTH = 300
HEIGHT = 300



def draw():
    screen.fill("black")
    
    w = WIDTH
    h = HEIGHT-200

    for i in range(20):
        r1 = Rect((0,0), (w,h))
        r1.center = 150,150
        r = random.randint(0,255)
        g = random.randint(0,255)
        b = random.randint(0,255)
        screen.draw.rect(r1,(r,g,b))
        w -= 10
        h +=10

    screen.draw.text("Hello", center=(150,150), color="white")

pgzrun.go()