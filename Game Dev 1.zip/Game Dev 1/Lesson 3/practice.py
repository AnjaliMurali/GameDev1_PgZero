import pgzrun
import random
WIDTH = 300
HEIGHT = 300
#w = WIDTH
#h = HEIGHT-200
def draw():
    screen.fill("black")
    #screen.draw.text("Hello",center=(150,150),color="red")
    w = WIDTH
    h = HEIGHT-200
    for i in range(20):
        r = random.randint(0,255)
        g = random.randint(0,255)
        b = random.randint(0,255)
        r1 = Rect((100,100),(w,h))
        r1.center = (150,150)
        screen.draw.rect(r1,"white")
        #screen.draw.filled_rect(Rect((100,100),(100,100)),"red")
        w -= 10
        h += 10
pgzrun.go()