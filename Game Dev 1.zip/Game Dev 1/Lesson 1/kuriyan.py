capitals ={"UK":"London"}
print(capitals)
capitals["Netherlands"] = "Amsterdam"
capitals["India"] = "New Delhi"
print(capitals)
print(capitals["Netherlands"])
x = list(capitals.keys())
print(x)
print(list(capitals.values()))
del(capitals["India"])
print(capitals)
