capitals={}
capitals["Netherlands"] = "Amsterdam"
capitals["Brazil"] = "Brazilia"
print(capitals)
print(list(capitals.keys()))
print(list(capitals.values()))

