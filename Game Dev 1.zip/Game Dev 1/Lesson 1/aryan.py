capitals = {}
capitals["Netherlands"] = "Amsterdam"
capitals["India"]="New Delhi"
print(capitals)
print(list(capitals.keys()))
print(list(capitals.values()))
del(capitals["India"])
print(capitals)

