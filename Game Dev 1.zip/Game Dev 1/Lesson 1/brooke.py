capitals = {"Netherlands":"Amsterdam", "UK":"London"}
print(capitals)
capitals["Germany"] = "Berlin"
print(capitals)
print(capitals["Netherlands"])