capitals = {"UK":"London","Netherlands":"Amsterdam"}
print(capitals)
capitals["India"] ="New Delhi"
print(capitals)
print(capitals["UK"])
x = list(capitals.keys())
print(x)
y = list(capitals.values())
print(y)
del(capitals["Netherlands"])
print(capitals)
if "UK" in capitals:
    print("Yes")
else:
    print("No")