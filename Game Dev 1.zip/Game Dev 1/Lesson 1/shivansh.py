capitals= {"UK":"London","Netherlands":"Amsterdam"}
print(capitals)
capitals["India"]="New Delhi"
print(capitals)
print(capitals["UK"])
del(capitals["Netherlands"])
print(capitals)
if "Netherlands" in capitals:
    print("Yes")
else:
    print("No")