capitals={}
capitals["UK"] = "London"
capitals["India"]="New Delhi"
print(capitals)
print(list(capitals.keys()))
print(list(capitals.values()))
print(capitals["India"])

