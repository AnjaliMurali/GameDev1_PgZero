pw={"User1":"123456789","Andrew":"Password123","Bob":"ABC123","Yusuf":"PQRSTuvw"}
x = input("Enter User name : ")
if(x in pw):
    y = input("Enter Pasword : ")
    if(y==pw[x]):
        print("You are successfully logged in")
    else:
        print("Incorrect password! ")
else:
    print("Username not found")
      
#If this is already done in class -  you can ask the learner to create a dictionary for Https Error Code and Message 
# enter the error code and it should display the error message. 
#Example: { 404: "Not Found", 500: "Internal Server Error" }

	