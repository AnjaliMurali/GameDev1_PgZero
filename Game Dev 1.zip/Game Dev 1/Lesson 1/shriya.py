capitals = {"Germany":"Berlin","Netherlands":"Amsterdam"}
print(capitals)
capitals["India"] = "New Delhi"
print(capitals)
print(capitals["Netherlands"])
if "Netherlands" in capitals:
    print("Yes")
else:
    print("No")

x = list(capitals.keys())
print(x)

y = list(capitals.values())
print(y)