capitals={}
capitals["India"]="New Delhi"
print("The newly added item is "+capitals["India"])
capitals["France"]="Paris"
capitals["UK"]="London"
print(capitals)
print(list(capitals.keys())[1]) #prints the second key in the list
print(list(capitals.values()))
#x=input("Enter country")
#y=capitals[x]
#print("The capital of " + x + " is " +y)
capitals["USA"]="Washington, D.C."
print(capitals)
print(capitals.get("India","Unknown"))
del(capitals["USA"])
print(capitals)
#print(capitals["USA"]) #creates error as key doesn't exist
print(capitals.get("USA","Unknown"))
print(len(capitals))
print("UK" in capitals)
print("London" in capitals) #Can check for only the keys, hence would return False 
countries=[]
for k in capitals:
    countries.append(k)
print(countries)
countries.sort()
print(countries)