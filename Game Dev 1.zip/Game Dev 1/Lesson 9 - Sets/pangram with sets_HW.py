"""
input_string = input("Enter a string: ")

input_set = set(input_string.lower())

alphabet_set = set('abcdefghijklmnopqrstuvwxyz')

difference_set = alphabet_set - input_set

if len(difference_set) == 0:
    print("The input string is a pangram.")
else:
    print("The input string is not a pangram.")

"""

#second method: 

p = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
p= set(p)
print(p)
har = input("enter a string?")
har=set(har)
print(har)
#print(len(p.intersection(har)))
if len(p.intersection(har)) == 26:
    print("ok")
else:
    print("never")

# print(len(p))
# print(len(har))
# print(len(p.intersection(har)))  