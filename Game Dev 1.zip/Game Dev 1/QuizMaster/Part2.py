import pgzrun

TITLE = "Quiz Master"
WIDTH = 800
HEIGHT = 480

marquee_box = Rect(0,0,800,50)
timer_box = Rect(670,70,110,120)
skip_box = Rect(670,200,110,260)
#part2
question_box = Rect(20,70,600,120)


time_left = 10
#part2
questions = []
question_count = 0
question_index = 0
question_file_name = "QuizMaster\questions.txt"


def draw():
    screen.fill(color="black")
    #screen.clear()
    screen.draw.filled_rect(marquee_box, "black")
    marquee_message = "Welcome To Quiz Master..." + f"Q: {question_index} of {question_count}"
    screen.draw.textbox(marquee_message, marquee_box, color="white")
    screen.draw.filled_rect(timer_box, "yellow")
    screen.draw.filled_rect(skip_box, "dark green")
    screen.draw.textbox(
        str(time_left),timer_box,
        color="white"
    )
    screen.draw.textbox(
        "Skip", skip_box,
        color="black", angle=-90
    )
    #Part2
    screen.draw.filled_rect(question_box, "navy blue")
    screen.draw.textbox(
        question[0].strip(), question_box,
        color="white", shadow=(0.5,0.5),
        scolor="dim grey"
    )

def update():
    move_marquee()

def move_marquee():
    marquee_box.x = marquee_box.x - 2
    if marquee_box.right < 0:
        marquee_box.left = WIDTH

def update_time_left():
    global time_left
    if time_left:
        time_left = time_left - 1
    #else:
        #gameover()

#Part2
def read_question_file():
    global question_count, questions
    q_file=open(question_file_name, "r")
    for question in q_file:
        questions.append(question)
        question_count = question_count + 1
        #print(questions)
    q_file.close()

def read_next_question():
    global question_index
    question_index = question_index + 1
    return questions.pop(0).split(",")

#Part2
read_question_file()
question = read_next_question()

clock.schedule_interval(update_time_left, 1)
pgzrun.go()