import pgzrun

TITLE = "Quiz Master"
WIDTH = 800
HEIGHT = 480

marquee_box = Rect(0,0,800,50)

question_count = 0
question_index = 0

def draw():
    screen.fill(color="black")
    #screen.clear()
    screen.draw.filled_rect(marquee_box, "black")
    marquee_message = "Welcome To Quiz Master..." + f"Q: {question_index} of {question_count}"
    screen.draw.textbox(marquee_message, marquee_box, color="white")

def update():
    move_marquee()

def move_marquee():
    marquee_box.x = marquee_box.x - 2
    if marquee_box.right < 0:
        marquee_box.left = WIDTH

pgzrun.go()