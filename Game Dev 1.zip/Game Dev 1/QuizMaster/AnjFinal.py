import pgzrun

TITLE = "Quiz Master"
WIDTH = 800
HEIGHT = 480

time_left = 10

marquee_box = Rect(0,0,800,50)
question_box = Rect(20,70,600,120)
timer_box = Rect(670,70,110,120)
answer_box1 = Rect(20,200,275,120)
answer_box2 = Rect(345,200,275,120)
answer_box3 = Rect(20,340,275,120)
answer_box4 = Rect(345,340,275,120)
skip_box = Rect(670,200,110,260)

answer_boxes = [answer_box1,answer_box2,answer_box3,answer_box4]
questions = []
question_file_name = "QuizMaster/questions.txt"
game_over=False
score=0

def draw():
    screen.fill(color="black")
    screen.draw.filled_rect(timer_box, "yellow")
    screen.draw.filled_rect(marquee_box, "black")
    marquee_message = "Welcome To Quiz Master..."
    screen.draw.textbox(marquee_message, marquee_box, color="white")
    screen.draw.textbox(
        str(time_left),timer_box,
        color="white", shadow=(0.7, 0.5),
        scolor="dim grey"
    )
    screen.draw.filled_rect(question_box, "navy blue")
    screen.draw.filled_rect(skip_box, "dark green")
    screen.draw.textbox(
        "Skip", skip_box,
        color="black", angle=-90
    )
    index = 1
    for answer_box in answer_boxes:
        screen.draw.filled_rect(answer_box, "dark orange")
        screen.draw.textbox(question[index].strip(), answer_box, color="black")
        index = index + 1
    
    screen.draw.textbox(
        question[0].strip(), question_box,
        color="white", shadow=(0.5,0.5),
        scolor="dim grey"
    )



def update():
    move_marquee()

def move_marquee():
    marquee_box.x = marquee_box.x - 2
    if marquee_box.right < 0:
        marquee_box.left = WIDTH

def update_time_left():
    global time_left
    if time_left:
        time_left = time_left - 1
    else:
        gameover()

clock.schedule_interval(update_time_left, 1)

def read_question_file():
    global question_count, questions
    q_file=open(question_file_name, "r")
    for question in q_file:
        questions.append(question)
        #question_count = question_count + 1
    #print(questions)
    q_file.close()

def read_next_question():
    return questions.pop(0).split(",") 

read_question_file()
question= read_next_question() 

def on_mouse_down(pos):
    global question, time_left,score
    index=1
    for ansbox in answer_boxes:
        if ansbox.collidepoint(pos):
            if index==int(question[5]):
                score = score + 1
                if questions:
                    question=read_next_question() 
                    time_left=10
                else:
                    gameover()
            else:
                if questions:
                    question=read_next_question() 

                    time_left=10
                else:
                    gameover()
        index+=1
        
    if skip_box.collidepoint(pos):
        if questions and not game_over:
            question=read_next_question() 
            time_left=10
        else:
             gameover()
    

def gameover():
    global game_over,question, time_left
    message = f"Game over!\nYou got {score} questions correct!"
    question = [message, "-","-","-","-",5]
    time_left = 0
    game_over=True

pgzrun.go()