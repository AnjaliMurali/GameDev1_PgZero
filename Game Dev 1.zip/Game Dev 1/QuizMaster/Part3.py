import pgzrun

TITLE = "Quiz Master"
WIDTH = 800
HEIGHT = 480

marquee_box = Rect(0,0,800,50)
timer_box = Rect(670,70,110,120)
skip_box = Rect(670,200,110,260)
#part2
question_box = Rect(20,70,600,120)
#Part3
answer_box1 = Rect(20,200,275,120)
answer_box2 = Rect(345,200,275,120)
answer_box3 = Rect(20,340,275,120)
answer_box4 = Rect(345,340,275,120)


time_left = 10
#part2
questions = []
question_count = 0
question_index = 0
question_file_name = "QuizMaster\questions.txt"
#part3
answer_boxes = [answer_box1,answer_box2,answer_box3,answer_box4]
score=0

def draw():
    screen.fill(color="black")
    #screen.clear()
    screen.draw.filled_rect(marquee_box, "black")
    marquee_message = "Welcome To Quiz Master..." + f"Q: {question_index} of {question_count}"
    screen.draw.textbox(marquee_message, marquee_box, color="white")
    screen.draw.filled_rect(timer_box, "yellow")
    screen.draw.filled_rect(skip_box, "dark green")
    screen.draw.textbox(
        str(time_left),timer_box,
        color="white"
    )
    screen.draw.textbox(
        "Skip", skip_box,
        color="black", angle=-90
    )
    #Part2
    screen.draw.filled_rect(question_box, "navy blue")
    screen.draw.textbox(
        question[0].strip(), question_box,
        color="white", shadow=(0.5,0.5),
        scolor="dim grey"
    )
    #part3
    index = 1
    for answer_box in answer_boxes:
        screen.draw.filled_rect(answer_box, "dark orange")
        screen.draw.textbox(question[index].strip(), answer_box, color="black")
        index= index+1
    
 


def update():
    move_marquee()

def move_marquee():
    marquee_box.x = marquee_box.x - 2
    if marquee_box.right < 0:
        marquee_box.left = WIDTH

def update_time_left():
    global time_left
    if time_left:
        time_left = time_left - 1
    #else:
        #gameover()

#Part2
def read_question_file():
    global question_count, questions
    q_file=open(question_file_name, "r")
    for question in q_file:
        questions.append(question)
        question_count = question_count + 1
        #print(questions)
    q_file.close()

def read_next_question():
    global question_index
    question_index = question_index + 1
    return questions.pop(0).split(",")

#part3
def on_mouse_down(pos):
    index = 1
    for box in answer_boxes:
        if box.collidepoint(pos):
            if index == int(question[5]):
                correct_answer()
            #else:
                #game_over()
        index = index + 1
    
    if skip_box.collidepoint(pos):
        skip_question()

#part3
def correct_answer():
    global question, time_left,score
    score = score + 1
    if questions:
        question = read_next_question()
        time_left = 10
    else:
        game_over()

#part3
def skip_question():
    global question, time_left
    if questions:
        question = read_next_question()
        time_left = 10
    else:
        game_over()


#part3
def game_over():
    global score, question, time_left, is_game_over
    if not questions:
        message = f"Game over!\nYou got {score} questions correct!"
        question = [message, "-","-","-","-",5]
    time_left = 0

#Part2
read_question_file()
question = read_next_question()



#Part2
clock.schedule_interval(update_time_left, 1)
pgzrun.go()


