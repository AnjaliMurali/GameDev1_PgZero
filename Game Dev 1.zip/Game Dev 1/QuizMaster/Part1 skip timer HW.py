import pgzrun

TITLE = "Quiz Master"
WIDTH = 800
HEIGHT = 480

marquee_box = Rect(0,0,800,50)
timer_box = Rect(670,70,110,120)
skip_box = Rect(670,200,110,260)

question_count = 0
question_index = 0
time_left = 10

def draw():
    screen.fill(color="black")
    #screen.clear()
    screen.draw.filled_rect(marquee_box, "black")
    marquee_message = "Welcome To Quiz Master..." + f"Q: {question_index} of {question_count}"
    screen.draw.textbox(marquee_message, marquee_box, color="white")
    screen.draw.filled_rect(timer_box, "yellow")
    screen.draw.filled_rect(skip_box, "dark green")
    screen.draw.textbox(
        str(time_left),timer_box,
        color="white"
    )
    screen.draw.textbox(
        "Skip", skip_box,
        color="black", angle=-90
    )

def update():
    move_marquee()

def move_marquee():
    marquee_box.x = marquee_box.x - 2
    if marquee_box.right < 0:
        marquee_box.left = WIDTH

def update_time_left():
    global time_left
    if time_left:
        time_left = time_left - 1
    #else:
        #gameover()


clock.schedule_interval(update_time_left, 1)
pgzrun.go()