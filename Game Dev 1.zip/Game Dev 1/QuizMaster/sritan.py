import pgzrun

WIDTH=1000
HEIGHT=700

marquee_box=Rect(0,0,1000,100)
question_box=Rect(50,130,900,150)
time_box=Rect(800,300,150,150)
skip_box=Rect(800,475,150,300)
ans_box=Rect(50,335,345,135)
ans_box2=Rect(415,335,345,135)
ans_box3=Rect(50,520,345,135)
ans_box4=Rect(415,520,345,135)

questions_filename="QuizMaster/questions.txt"

questions=[]

answers=[ans_box,ans_box2,ans_box3,ans_box4]

def draw():  
    screen.fill("black")
    screen.draw.filled_rect(marquee_box,"Black")
    screen.draw.filled_rect(question_box,"Pink")
    screen.draw.filled_rect(time_box,"Blue")
    screen.draw.filled_rect(skip_box,"Green")
    screen.draw.filled_rect(ans_box,"orange")
    screen.draw.filled_rect(ans_box2,"orange")
    screen.draw.filled_rect(ans_box3,"orange")
    screen.draw.filled_rect(ans_box4,"orange")
    screen.draw.textbox("Welcome to Quiz Master",marquee_box,color="White")
    screen.draw.textbox(question[0],question_box)
    index=1
    for ans in answers:
        screen.draw.textbox(question[index],ans,color="black")
        index=index+1
        

def on_mouse_down(pos):
    global question
    index=1
    for ans in answers:
        if ans.collidepoint(pos):
            if index==int(question[5]): 
                if questions:
                    question=read_next_question()
        index=index+1

def move():
    marquee_box.x=marquee_box.x-6
    if marquee_box.right<0:
        marquee_box.x=1000

def update():
    move()


def read_question():
    q_file=open(questions_filename,"r")
    for question in q_file:
        questions.append(question)
    
    print(questions)
    q_file.close()

read_question()

def read_next_question():
    return questions.pop(0).split(",")

    
question=read_next_question()











pgzrun.go()