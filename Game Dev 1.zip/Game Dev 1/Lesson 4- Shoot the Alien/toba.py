import pgzrun

WIDTH= 400
HEIGHT = 400

a = Actor("alien")
a.x = 200
a.y = 200
msg = "shoot the alien"

def draw():
    screen.fill("red")
    a.draw()
    screen.draw.text(msg,(100,50))


pgzrun.go()