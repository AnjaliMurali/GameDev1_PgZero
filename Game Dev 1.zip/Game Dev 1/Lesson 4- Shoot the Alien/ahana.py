import pgzrun

WIDTH = 400
HEIGHT=400

alien = Actor("alien")
alien.x = 200
alien.y=200

def draw():
    screen.fill("red")
    alien.draw()

pgzrun.go()