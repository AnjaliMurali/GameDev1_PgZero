import pgzrun
import random

WIDTH=800
HEIGHT=400
# check how to add timer and increase the font size. 
alien = Actor("alien")
#alien.x =  50
#alien.y = 50
ms = "Catch the alien"
shot=0
miss=0
#color = "yellow"
def draw():
    #screen.fill(color)
    screen.fill("red")
    alien.draw()
    screen.draw.text(ms,(300,300))
    screen.draw.text("shot:"+str(shot),(500,300))
    screen.draw.text("miss:"+str(miss),(500,330))

def on_mouse_down(pos):
    global ms,shot,miss,color
    #print(alien.collidepoint(pos))
    if alien.collidepoint(pos):
        alien.x = random.randint(50,750)
        alien.y = random.randint(50,HEIGHT-50)
        ms = "Good Shot! "
        shot += 1
        #color = "green"
    else:
        ms="You missed! "
        miss += 1
        #color = "red"
pgzrun.go()