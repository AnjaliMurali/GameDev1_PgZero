import pgzrun

WIDTH = 500
HEIGHT = 500

alien = Actor("alien")
alien.x = 250
alien.y = 250

def draw():
    screen.fill("pink")
    alien.draw()

pgzrun.go()