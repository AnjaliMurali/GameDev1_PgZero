import pgzrun

WIDTH = 800
HEIGHT = 400

alien = Actor("alien")
alien.x = 400
alien.y=200

msg = "Catch the alien"

def draw():
    screen.fill("red")
    alien.draw()
    screen.draw.text(msg,(300,100))

pgzrun.go()
