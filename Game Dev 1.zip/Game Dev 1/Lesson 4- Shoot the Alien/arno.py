import pgzrun

WIDTH = 500
HEIGHT = 500

a = Actor("alien")
a.x = 250
a.y = 250

def draw():
    screen.fill("purple")
    a.draw()

pgzrun.go()