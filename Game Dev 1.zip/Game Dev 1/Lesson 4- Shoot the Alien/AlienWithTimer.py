import pgzrun
import random

WIDTH =800
HEIGHT = 400
a=Actor("alien")
a.x=400
a.y=250
msg="Catch the alien"
hits=0
misses=0
game_over=False
score=0
timer = 10 #initializing the timer variable

def draw():
    screen.fill("#010029")
    a.draw()
    screen.draw.text(msg,(330,330))
    screen.draw.text("Hits="+str(hits),(10,10))
    screen.draw.text("Misses="+str(misses),(715,10))
    if game_over:   #if not game_over: 
        screen.fill("#010029")
        screen.draw.text("Your Score: " +str(score), (330, 330), fontsize=100, color="red") 
    else: 
         screen.draw.text("Time: " + str(int(timer)), (380, 10), color="white")

    
def update(dt): #if you want to display the timer on the screen
    global timer, game_over
    if not game_over:
        # Update the timer by subtracting the time passed since the last frame
        timer -= dt
        # End the game if the timer reaches zero
        if timer <= 0:
            time_up()

def time_up():
    global score, hits, misses, game_over
    game_over=True
    score=hits-misses

def on_mouse_down(pos):
    global msg, misses, hits
    if a.collidepoint(pos):
        a.x=random.randint(0,800)
        a.y=random.randint(0,500)
        hits=hits+1
        msg="Good Shot!"
    else:
        msg="You Missed!"
        misses=misses+1

clock.schedule(time_up, 10.0)

pgzrun.go()