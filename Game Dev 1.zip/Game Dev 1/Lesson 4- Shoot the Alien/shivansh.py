import pgzrun

WIDTH = 300
HEIGHT = 300

a = Actor("alien")
a.x = 100
a.y = 200

def draw():
    screen.fill("blue")
    a.draw()

pgzrun.go()