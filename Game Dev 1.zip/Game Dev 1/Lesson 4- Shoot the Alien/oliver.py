import pgzrun
import random

WIDTH = 500
HEIGHT=400

alien = Actor("alien")

def draw():
   screen.fill("indigo") 
   alien.draw()

def on_mouse_down(pos):
   if alien.collidepoint(pos):
      alien.x = random.randint(100,400)
      alien.y = random.randint(100,300)
      

pgzrun.go()
