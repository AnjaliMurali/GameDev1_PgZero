import pgzrun
import random

WIDTH = 800
HEIGHT = 600

# Starting position
circle_x = WIDTH // 2
circle_y = HEIGHT // 2

# List of colors to cycle through
colors = ["red", "blue", "green"]
color_index = 0


def draw():
    screen.clear()
    screen.fill("white")
    screen.draw.filled_circle((circle_x, circle_y), 30, colors[color_index])
    #screen.draw.filled_circle((circle_x, circle_y), 30, (random.randint(0,255),random.randint(0,255),random.randint(0,255)))
    

def on_mouse_down(pos):
    global circle_x, circle_y, color_index

    # Move the circle to the mouse click
    circle_x, circle_y = pos

    # Change to the next color
    color_index = (color_index + 1) % len(colors)


pgzrun.go()