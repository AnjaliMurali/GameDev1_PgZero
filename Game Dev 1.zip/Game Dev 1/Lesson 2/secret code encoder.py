"""
Secret Code 🔐
Create a dictionary that maps letters to numbers, such as:

A → 1, B → 2, C → 3... (u can make it interesting by adding symbols also)

Ask the user for a word and convert it into its secret numerical code.
"""


code = {
    "A": 1, "B": 2, "C": 3, "D": 4, "E": 5,
    "F": 6, "G": 7, "H": 8, "I": 9, "J": 10,
    "K": 11, "L": 12, "M": 13, "N": 14, "O": 15,
    "P": 16, "Q": 17, "R": 18, "S": 19, "T": 20,
    "U": 21, "V": 22, "W": 23, "X": 24, "Y": 25,
    "Z": 26
}

word = input("Enter a word: ").upper()

secret_code = ""

for letter in word:
    if letter in code:
        secret_code += str(code[letter]) + " "
    else:
        secret_code += letter + " "

print("Secret code:", secret_code)