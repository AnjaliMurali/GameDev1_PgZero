"""
Mystery Gift 
Dictionarygifts = {
    1: "Teddy Bear",
    2: "Chocolate",
    3: "Game",
    4: "Mystery Prize",
    5: "Headphones"
}
Ask the player to choose a box from 1–5 and display the prize.
Challenge: Randomly shuffle the prizes before the game starts.

"""

import random

gifts = {
    1: "Teddy Bear",
    2: "Chocolate",
    3: "Game",
    4: "Mystery Prize",
    5: "Headphones"
}

# Get the prizes and shuffle them
prizes = list(gifts.values())
random.shuffle(prizes)

# Put the shuffled prizes back into the boxes
for box in gifts:
    gifts[box] = prizes[box - 1]

# Ask the player to choose a box
choice = int(input("Choose a box (1-5): "))

# Display the prize
print("You won:", gifts[choice])