fruitTracker={}
for i in range(5):
    fruitChoice=input("fruit : ")
    if fruitChoice not in fruitTracker:
        fruitTracker[fruitChoice]=1
    else:
        fruitTracker[fruitChoice]+=1
print(fruitTracker)
"""
for i in fruitTracker:
    print(i + ":"+ str(fruitTracker[i]))
"""