print("Count the occurrence of vowels in the string entered by the user")
inputStr = input("Enter the string - ")
inputStr = inputStr.lower()
print(inputStr)
vowels = {
    "a":0,
    "e":0,
    "i":0,
    "o":0,
    "u":0
    }
    
for c in inputStr:
    print(c)
    if c in vowels:
        vowels[c] += 1
        
print(vowels)