def char_frequency(s):
    frequency = {}

    for char in s:
        if char != " ":          # Ignore spaces
            if char in frequency:
                frequency[char] += 1
            else:
                frequency[char] = 1

    return frequency


# Example
text = input("enter your sentence : ")
print(char_frequency(text))