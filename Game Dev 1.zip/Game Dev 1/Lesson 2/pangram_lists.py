input=input("enter numbers :")
#numList="0123456789"
numList = ["0","1","2","3","4","5","6","7","8","9"]
blacklist=[]
numCount=0
for i in input:
    if i in numList:
        if i not in blacklist:
            numCount+=1
            blacklist.append(i)
if numCount==10:
    print("yes")
else:
    print("no")

print(blacklist)