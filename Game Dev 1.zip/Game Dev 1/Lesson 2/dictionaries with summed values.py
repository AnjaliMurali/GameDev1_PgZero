d1 = {"apple":1,"grapes":2,"strawberry":1}
d2={"grapes":1,"mango":2}
d3={}

for f1 in d1:
    common = False
    for f2 in d2:
        #print(f1,f2)
        if f1==f2:
            common = True
            d3[f1] = d1[f1]+d2[f2]
            print(d3)
    if common == False:
        d3[f1] = d1[f1]
        #d3[f2] = d2[f2]
for f2 in d2:
    if f2 not in d3:
        d3[f2] = d2[f2]
print(d3)