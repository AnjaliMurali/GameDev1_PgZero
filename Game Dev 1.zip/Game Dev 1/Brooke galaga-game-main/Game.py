import pgzrun


WIDTH = 1200
HEIGHT = 600


bugs = []
bullets = []
for j in range(3):
    for i in range(4):
        bug = Actor("bug")
        bug.x = 20 + 70 * i
        bug.y = 20 + 60 * j
        bugs.append(bug)
galaga = Actor("galaga")
galaga.x = 600
galaga.y = 550




def draw():
    screen.fill("blue")
    galaga.draw()
    for i in bugs:
        i.draw()
    for b in bullets:
        b.draw()


def update():

    if keyboard.left:
        galaga.x -= 5
        if galaga.x < 0:
            galaga.x = 0

    if keyboard.right:
        galaga.x += 5
        if galaga.x > 1200:
            galaga.x = 1200
    for bullet in bullets:
        bullet.y -= 5


def on_key_down(key):
    global bullets
    if key == keys.SPACE:
        bullet = Actor("bullet")
        bullets.append(bullet)
        bullet.x = galaga.x
        bullet.y = galaga.y - 50






    
    








pgzrun.go()