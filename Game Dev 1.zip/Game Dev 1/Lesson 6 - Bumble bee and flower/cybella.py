import pgzrun

WIDTH = 700
HEIGHT = 500

bee = Actor("bee")
bee.pos = 350,250

def draw():
    bee.draw()
    screen.blit("background",(0,0))



pgzrun.go()