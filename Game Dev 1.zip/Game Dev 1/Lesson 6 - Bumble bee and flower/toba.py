import pgzrun
from random import randint
WIDTH = 400
HEIGHT = 400
points = 0
bee = Actor("bee")
bee.pos = 200,200
flow = Actor("flower")
flow.pos = 100,100
def draw():
    screen.blit("background",(0,0))
    bee.draw()
    flow.draw()
    screen.draw.text("Points: "+ str(points) , (20,20))
def update():
    global points
    if keyboard.w:
        bee.y = bee.y - 2
    if keyboard.a:
        bee.x = bee.x - 2
    if keyboard.s:
        bee.y = bee.y + 2
    if keyboard.d:
        bee.x = bee.x + 2
    if bee.colliderect(flow):
        flow.x = randint(20,380)
        flow.y = randint(20,380)
        points = points + 0.01
pgzrun.go()