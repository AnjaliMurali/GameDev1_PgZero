matrix = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
]

reverse_matrix = []

# Go through the rows from the last row to the first row
for i in range(len(matrix) - 1, -1, -1):

    new_row = []

    # Go through the elements from the last to the first
    for j in range(len(matrix[i]) - 1, -1, -1):
        new_row.append(matrix[i][j])

    reverse_matrix.append(new_row)


print(reverse_matrix)