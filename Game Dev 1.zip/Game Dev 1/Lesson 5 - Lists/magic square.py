"""
Check if a matrix is a magic square - 
A magic square has the same sum for every row, every column, and both diagonals.
"""

matrix = [
    [8, 1, 6],
    [3, 5, 7],
    [4, 9, 2]
]

n = len(matrix)

# Sum of first row
magic_sum = sum(matrix[0])

is_magic = True

# Check rows
for i in range(n):
    if sum(matrix[i]) != magic_sum:
        is_magic = False

# Check columns
for j in range(n):
    total = 0
    for i in range(n):
        total += matrix[i][j]

    if total != magic_sum:
        is_magic = False

# Check main diagonal
total = 0
for i in range(n):
    total += matrix[i][i]

if total != magic_sum:
    is_magic = False

# Check other diagonal
total = 0
for i in range(n):
    total += matrix[i][n - 1 - i]

if total != magic_sum:
    is_magic = False

if is_magic:
    print("It is a Magic Square")
else:
    print("It is not a Magic Square")