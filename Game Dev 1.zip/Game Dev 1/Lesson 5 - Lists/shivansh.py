matrix = [[1,2,3,11],[4,5,6,12],[7,8,9,13]]
print(matrix)
print(matrix[2][0])
for i in range(3):
    for j in range(4):
        print(matrix[i][j], end=" ")
    print("\n")