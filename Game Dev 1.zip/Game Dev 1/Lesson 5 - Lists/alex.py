matrix = [[1,2,3], [4,5,6],[7,8,9]]
print(matrix)

print(len(matrix))

print(len(matrix[0]))

print(matrix[1][2])

for row in range(3):
    for col in range(3):
        print(matrix[row][col], end = " ")
    print("\n")