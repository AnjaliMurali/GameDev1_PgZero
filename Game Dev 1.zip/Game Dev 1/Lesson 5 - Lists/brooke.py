matrix = [[1,2,3],[4,5,6],[7,8,9]]
print(matrix)
#rows:
print(len(matrix))
#columns
print(len(matrix[0]))
print(matrix[2][1])