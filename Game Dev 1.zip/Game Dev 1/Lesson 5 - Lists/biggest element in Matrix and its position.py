matrix = [
    [4, 7, 2],
    [9, 1, 5],
    [3, 8, 6]
]

maximum = matrix[0][0]
max_row = 0
max_col = 0

for i in range(len(matrix)):
    for j in range(len(matrix[i])):

        if matrix[i][j] > maximum:
            maximum = matrix[i][j]
            max_row = i
            max_col = j

print("Maximum element:", maximum)
print("Position:", max_row, max_col)